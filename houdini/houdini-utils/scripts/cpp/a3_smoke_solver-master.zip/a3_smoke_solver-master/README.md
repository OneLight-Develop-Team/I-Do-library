Builded for houdini16 on ubuntu 14 with gcc4.8 Builded for houdini16 on windows 10 with visual studio 2015

To install copy so/dll, otls to you houdini preferences dso folder.

Default in linux ~/houdiniX.Y/ Default in window C:\Users\user\Documents\houdiniX.Y\

You should install vdb_to_field as well to look at example hip
https://github.com/abryutinalexey/vdb_to_field
https://vimeo.com/216432705
