# vdb_to_field

Build for houdini16 and 15.5 on ubuntu 14 with gcc4.8
Builded for houdini16 and 15.5 on windows 10 with visual studio 2015

To install copy so/dll to you houdini preferences dso folder. 

Default in linux ~/houdiniX.Y/dso
Default in window C:\Users\user\Documents\houdiniX.Y\dso

To build on linux set INSTDIR and HFS then "make install"
more info here http://sidefx.com/docs/hdk/_h_d_k__intro__compiling.html

To build on windows please look this tutorial https://vimeo.com/17195536
thanks to Milan Suk
