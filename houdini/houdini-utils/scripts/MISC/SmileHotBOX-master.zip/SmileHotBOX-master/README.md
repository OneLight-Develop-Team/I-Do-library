# SmileHotBOX
Overview

This is an open source framework for load Houdini tools,you can quickly customize the tools and install them on the Interface.It is very meaningful to help you simplify the complex operation of common use,They have used more than a year, good improvement of their own operation, so the source code for everyone to share.

install

Written in a cross platform use python,Here is the way to install windows7+, the same method of Linux and OS

1,Copy  INSTALLPATH/HoudiniHotBox17.0/houdini.env file to  C:\Users\Administrator\Documents\houdini16.0  and open the houdini.env ,Modifying the environment variable corresponding to your path   SMILEHOTBOX = C:/hotboxtest/HoudiniHotBox17.0  

2,Copy  HoudiniHotBox17.0\toolbar\SmileHotBox17.shelf file to C:\Users\Administrator\Documents\houdini16.0\toolbar
Set over and enjoy it

Support

You can tell me your needs by mail, including your problems,Telephone +8618810865732
Because my personal thoughts are limited, I hope you can give me a better idea of your mail. I will update it to GitHub for the first time. I am looking forward to receiving your mail, any suggestion, email:change52092@yahoo.com.
This is a good preview of the function
Gradually update the use of video tutorials，It will be published in vimeo  this is show reel https://vimeo.com/216009486


Known Issues

Ninety percent of the functionality you can use across the platform,Some functions only support windows, but TD developers are easy to correct. Some functions are too large dependence ,Pay attention to the following link to get . SmileFX   https://weidian.com/s/1225774756?ifr=shopdetail&wfr=c
The icon, please do not use it for other commercial uses,thanks to sidefx for providing icons test,If there is a copyright infringement, please contact me and I will delete it immediately.thanks Sidefx.    Email:change52092@yahoo.com

Release Notes
2018/3/27 smileHotBox 17.0   Initial relea
