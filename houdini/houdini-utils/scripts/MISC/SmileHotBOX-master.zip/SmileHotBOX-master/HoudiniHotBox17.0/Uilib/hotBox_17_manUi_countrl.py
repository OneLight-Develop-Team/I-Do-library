import hou
import os
sysPath = os.getenv('SMILEHOTBOX')
#os.environ["SMILEHOTBOX"] =sysPath
LibPath =sysPath+r"/Uilib"
LibPath2 =sysPath+r"/lib"
WritePrefPath =  sysPath+r"/pref/"
import sys
sys.path.append(sysPath)
sys.path.append(LibPath)
sys.path.append(LibPath2)
import math
import s_GetButton
import s_GetColor
import s_GetShape
import getWindowPose
import os
import GuiEnv
import s_GetHoudiniEnvenPath
import hou
def selectClassButuonClass():
    a = hou.ui.curDesktop()
    pane = a.paneUnderCursor()
    currentTab = pane.currentTab()
    name = currentTab.type().name()
    return name
#readFile
houdiniHotPathIconPath = sysPath+"/Icon/"
nodeClass = selectClassButuonClass()
s_button= s_GetButton.getButton(nodeClass)
fatherNumer = s_button.getFatherButtonNum()
PythonfilePath =LibPath2


color= s_GetColor.getColor()
shape= s_GetShape.getShape()
#Calculating angle
def getangle(a,b):
    lenA= math.sqrt(a[0]*a[0]+a[1]*a[1])
    lenB = math.sqrt(b[0] * b[0] + b[1] * b[1])
    A_B= a[0]*b[0] +a[1]*b[1]
    if(lenA*lenB !=0 ):
        arcC= A_B/(lenA*lenB)
        arcc=    math.acos(arcC)
        if a[1]>=0 and a[0]>0:
            return arcc*180/(math.pi)
        elif a[1]>=0 and a[0] < 0 :
            return arcc * 180 / (math.pi)

        elif a[0]<0 and a[1] < 0 :
            return 360 - arcc * 180 / (math.pi)
        elif a[0]>0 and a[1] <0:
            return 360- arcc * 180 / (math.pi)

def Hot7getLib3():
    new_a =[]
    s_houdiniEnvenPaths = s_GetHoudiniEnvenPath.readHoudiniEnv().read()
    for s_childEnvPath in s_houdiniEnvenPaths:
        path2= s_childEnvPath.split(" = ")[-1].split("\n")[0]
        a = os.listdir(path2)
        index = 0
        for i in a:
            a[index] = i.split(".py")[0]
            index +=1

        for i in a:
            if i not in new_a:
                new_a.append(i)
    return  new_a



def Hot7getLib2(lib2Path):

    a = os.listdir(lib2Path)
    index = 0
    for i in a:
        a[index] = i.split(".py")[0]
        index +=1

    new_a =[]

    for i in a:
        if i not in new_a:
            new_a.append(i)
    new_add_form3=  Hot7getLib3()
    for thread in new_add_form3:

        new_a.append(thread)
    return  new_a
def Hot7getIconF(IconPath):
    a = os.listdir(IconPath)
    return  a

pythonFilelistL2 = Hot7getLib2(PythonfilePath)
IconFilelistL =Hot7getIconF(houdiniHotPathIconPath)

#ui start
from PySide2 import QtCore, QtGui, QtWidgets
#start ui
class Example(QtWidgets.QWidget):
    def __init__(self):
        super(Example, self).__init__()

        self.line = []
        self.arrButtonPose =[]
        self.windowStartX       =0
        self.windowStartY       = 0
        self.windowXSize        = 1200
        self.windowYSize        = 580
        self.mousePose =[0,0]
        
        try:
            
            self.mousePose[0] = getWindowPose.getPose().x()
            self.mousePose[1] = getWindowPose.getPose().y()
            
        except:
            print "getWindowPose error"
        self.windowCenterPointx =self.windowStartX + self.windowXSize/2
        self.windowCenterPointY = self.windowStartY -self.windowYSize/2
        #color set and line set
        self.insideColor        = color.getInsideColor()
        self.lineColor          = color.getLineColor()
        self.lineWidth          = color.lineWidth()
        self.outsideColor       = color.getOitsideColor()
        self.selectColor        =color.getSelectColor()
        #shape:
        self.cellCenterXY       =[self.windowStartX+0.5*self.windowXSize+300,self.windowStartY+0.5*self.windowYSize]
        self.insideShapeRs      =shape.insideShapeRs()
        self.outsideShapeRs     =shape.outsideShapeRs()
        self.midsideShapeRs     = shape.midsideShapeRs()
        self.childangleRangeset =shape.childPerAngle()

        #countrl clickd
        self.inSelectIndexArr   =[]
        self.outSelectIndexArr  =[]
        self.mouseAngleArr      =[0]
        self.chindrenMouseAngleArr =[0]
        self.fatherindex        =6
        self.insideTextAngele =0
        #set in num
        self.fatherindex1       =fatherNumer
        self.childrenindex      =5
        self.childrenAngleRange =0

        self.childrenallIndexArr =[]
        self.lenMouse = 0
        self.fatherNameArr =[]
        self.fatherIconNameArr =[]
        self.childNmaeArr =[]
        self.childIconNmaeARR =[]
        self.runPythonName =""
        #text
        self.inSideTextSize =shape.inForntSize()
        self.outSideTextSize =shape.inForntSize()
        self.insedeTextColor =color.inForntColor()
        self.outSideTextColor =color.outForntColor()
        self.selectTextColor =color.selectForntColor()
        #icon
        self.insideIconOffSetY =10
        self.OutSideIconOffSetY =5
        self.inInitImageSize =[40,40]
        self.OutInitImageSize =[25,25]

        for i in  range(self.fatherindex1):
            # read file bt current inSelectIndexArr
            #if inSelectIndexArr[-1] :
                # read file name+"inSelectIndexArr[-1]"
                #append getnum

            self.childrenallIndexArr.append(s_button.getButton_indexInfo(i)[2])
        for i in  range(self.fatherindex1):
            # read file bt current inSelectIndexArr
            #['name', 'iconName', 6, [['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName']]]
            #if inSelectIndexArr[-1] :
                # read file name+"inSelectIndexArr[-1]"
                #append getnum

            self.fatherNameArr.append(s_button.getButton_indexInfo(i)[0])
            self.fatherIconNameArr.append(s_button.getButton_indexInfo(i)[1])
        #current start ui
        #father:
        self.readCurrentNameArr =[]
        self.currentIconClassName =""
        self.tempCurrentIconName ="None"
        self.fatherIconViewPath  ="None"

        #child:
        self.childrenCurrentImageArr =[]
        self.currentIconChildrenClassName =""

        #init ui
        #GuiEnv.run()
        self.initUI()

    def reloadFatherInfo(self):


        self.fatherNameArr =[]
        self.fatherIconNameArr=[]
        for i in  range(self.fatherindex1):
            # read file bt current inSelectIndexArr
            #['name', 'iconName', 6, [['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName']]]
            #if inSelectIndexArr[-1] :
                # read file name+"inSelectIndexArr[-1]"
                #append getnum

            self.fatherNameArr.append(s_button.getButton_indexInfo(i)[0])
            self.fatherIconNameArr.append(s_button.getButton_indexInfo(i)[1])
        self.update()

    def initUI(self):

        self.setGeometry(self.mousePose[0]-0.5*self.windowXSize, self.mousePose[1]-0.5*self.windowYSize,self.windowXSize, self.windowYSize)

        self.setMaximumSize(self.windowXSize, self.windowYSize)
        self.setMinimumSize(self.windowXSize, self.windowYSize)


        self.setWindowTitle('HoudiniHotBox17_Master')
        self.initUICount()
        #self.setWindowOpacity(1)
        #self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        #self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        #self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
	  #self.setProperty("houdiniStyle", True)	
        self.show()

    def initUICount(self):
        #init python filePath
        self.PyhonfileList = QtWidgets.QCompleter(pythonFilelistL2)
        self.FatherNameList = QtWidgets.QCompleter(self.fatherNameArr)
        self.IconFilelistLCom = QtWidgets.QCompleter(IconFilelistL)
        #father
        self.IconCurrentFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentIconClassName)
        self.IconCurrentFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentFilelistL)
        #children
        self.IconCurrentChildrenFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentIconChildrenClassName)
        self.IconCurrentChildrenFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentChildrenFilelistL)


        self.lineeditor_label1 = QtWidgets.QLabel(self)
        self.lineeditor_label1.setGeometry(QtCore.QRect(30,20,71,20))
        self.lineeditor_label1.setObjectName("lineeditor_label1")
        self.lineeditor_label1.setText("Node Class:")
        self.com = QtWidgets.QCompleter(["Sop","Object","Dop","Driver","Shop","Vop","default"])
        #allfilepath

        self.addItem1=QtWidgets.QComboBox(self)
        self.addItem1.setGeometry(QtCore.QRect(110,20,100,20))
        self.addItem1.setObjectName("addItem1")
        self.addItem1.addItem("Sop")
        self.addItem1.addItem("Object")
        self.addItem1.addItem("Dop")
        self.addItem1.addItem("Driver")
        self.addItem1.addItem("Shop")
        self.addItem1.addItem("Vop")
        self.addItem1.addItem("default")
        self.addItem1.setEditable(True)
        self.addItem1.setCompleter(self.com)
        self.addItem1.setEditText("Sop")



        ##########################################
        self.lineeditor_label3 = QtWidgets.QLabel(self)
        self.lineeditor_label3.setGeometry(QtCore.QRect(30,120,71, 16))
        self.lineeditor_label3.setObjectName("lineeditor_label2")
        templineeditor_label3Text =""
        try:
            templineeditor_label3Text =self.readCurrentNameArr[-1][1]
        except:
            pass
        self.lineeditor_label3.setText(templineeditor_label3Text)


        self.lineeditor_label4 = QtWidgets.QLabel(self)
        self.lineeditor_label4.setGeometry(QtCore.QRect(110,100,71, 16))
        self.lineeditor_label4.setObjectName("lineeditor_label2")
        self.lineeditor_label4.setText("NewName|")

        self.lineeditor_label5 = QtWidgets.QLabel(self)
        self.lineeditor_label5.setGeometry(QtCore.QRect(240,100,71, 16))
        self.lineeditor_label5.setObjectName("lineeditor_label2")
        self.lineeditor_label5.setText("Icon Class|")

        self.lineeditor_label6 = QtWidgets.QLabel(self)
        self.lineeditor_label6.setGeometry(QtCore.QRect(370,100,71, 16))
        self.lineeditor_label6.setObjectName("lineeditor_label2")
        self.lineeditor_label6.setText("Icon Name|")

        self.lineeditor_label7 = QtWidgets.QLabel(self)
        self.lineeditor_label7.setGeometry(QtCore.QRect(500,100,71, 16))
        self.lineeditor_label7.setObjectName("lineeditor_label2")
        self.lineeditor_label7.setText("Icon View|")


        self.hline = QtWidgets.QFrame(self)
        self.hline.setGeometry(QtCore.QRect(30, 150, 580, 16))
        self.hline.setFrameShape(QtWidgets.QFrame.HLine)
        self.hline.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline.setObjectName("line")

        self.hline1 = QtWidgets.QFrame(self)
        self.hline1.setGeometry(QtCore.QRect(90, 110, 20, 100))
        self.hline1.setFrameShape(QtWidgets.QFrame.VLine)
        self.hline1.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline1.setObjectName("line")

        self.hline2 = QtWidgets.QFrame(self)
        self.hline2.setGeometry(QtCore.QRect(220, 110, 20, 100))
        self.hline2.setFrameShape(QtWidgets.QFrame.VLine)
        self.hline2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline2.setObjectName("line")

        self.hline3 = QtWidgets.QFrame(self)
        self.hline3.setGeometry(QtCore.QRect(350, 110, 20, 100))
        self.hline3.setFrameShape(QtWidgets.QFrame.VLine)
        self.hline3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline3.setObjectName("line")

        self.hline4 = QtWidgets.QFrame(self)
        self.hline4.setGeometry(QtCore.QRect(480, 110, 20, 100))
        self.hline4.setFrameShape(QtWidgets.QFrame.VLine)
        self.hline4.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline4.setObjectName("line")

        self.hline5 = QtWidgets.QFrame(self)
        self.hline5.setGeometry(QtCore.QRect(600, 0, 20, 581))
        self.hline5.setFrameShape(QtWidgets.QFrame.VLine)
        self.hline5.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.hline5.setObjectName("line")


        ######################Init father Pathon Path
        self.addItem_Father=QtWidgets.QComboBox(self)
        self.addItem_Father.setGeometry(QtCore.QRect(110,120,110,20))
        self.addItem_Father.setObjectName("addItem1")
        self.addItem_Father.setEditable(True)
        self.addItem_Father.setCompleter(self.FatherNameList)
        self.additemFromNode(self.addItem_Father,self.fatherNameArr)
        self.addItem_Father.setEditText(self.fatherNameArr[0])

        self.addItem_FatherIcon=QtWidgets.QComboBox(self)
        self.addItem_FatherIcon.setGeometry(QtCore.QRect(240,120,110,20))
        self.addItem_FatherIcon.setObjectName("addItem2")
        self.addItem_FatherIcon.setEditable(True)
        self.addItem_FatherIcon.setCompleter(self.IconFilelistLCom)
        self.additemFromNode(self.addItem_FatherIcon,IconFilelistL)
        self.addItem_FatherIcon.setEditText("COMMON")
        self.addItem_FatherIcon.activated.connect(self.currentTextChange)

        self.addItem_FatherIconName=QtWidgets.QComboBox(self)
        self.addItem_FatherIconName.setGeometry(QtCore.QRect(370,120,110,20))
        self.addItem_FatherIconName.setObjectName("addItem3")
        self.addItem_FatherIconName.setEditable(True)
        self.addItem_FatherIconName.setCompleter(self.IconCurrentFilelistLCom)
        self.additemFromNode(self.addItem_FatherIconName,self.IconCurrentFilelistL)
        self.addItem_FatherIconName.setEditText("")
        self.addItem_FatherIconName.activated.connect(self.currentTextChange1)
        ##70
        ##################################################################################
        #child countrl Labe
        self.lineeditor_label3_children = QtWidgets.QLabel(self)
        self.lineeditor_label3_children.setGeometry(QtCore.QRect(30,180,71, 16))
        self.lineeditor_label3_children.setObjectName("lineeditor_label2_children")
        templineeditor_label3Text = self.runPythonName
        try:
            lineeditor_label3_children =self.readCurrentNameArr[-1][1]
        except:
            pass
        self.lineeditor_label3_children.setText(templineeditor_label3Text)
        # get python file current
        self.addItem_childrenNewName=QtWidgets.QComboBox(self)
        self.addItem_childrenNewName.setGeometry(QtCore.QRect(110,180,110,20))
        self.addItem_childrenNewName.setObjectName("addItem1_childrenNew")
        self.addItem_childrenNewName.setEditable(True)
        self.addItem_childrenNewName.setCompleter(self.PyhonfileList)
        self.additemFromNode(self.addItem_childrenNewName,pythonFilelistL2)
        self.addItem_childrenNewName.setEditText(pythonFilelistL2[0])

        # get Icon Class current
        self.addItem_childrenIconClass=QtWidgets.QComboBox(self)
        self.addItem_childrenIconClass.setGeometry(QtCore.QRect(240,180,110,20))
        self.addItem_childrenIconClass.setObjectName("addItem1_childrenIconClass")
        self.addItem_childrenIconClass.setEditable(True)
        self.addItem_childrenIconClass.setCompleter(self.IconFilelistLCom)
        self.additemFromNode(self.addItem_childrenIconClass,IconFilelistL)
        self.addItem_childrenIconClass.setEditText(pythonFilelistL2[0])
        self.addItem_childrenIconClass.activated.connect(self.currentChildrenTextChange)
        # set Icon name Current
        self.addItem_ChildrenIconName=QtWidgets.QComboBox(self)
        self.addItem_ChildrenIconName.setGeometry(QtCore.QRect(370,180,110,20))
        self.addItem_ChildrenIconName.setObjectName("addItem3_childrenIconName")
        self.addItem_ChildrenIconName.setEditable(True)
        self.addItem_ChildrenIconName.setCompleter(self.IconCurrentChildrenFilelistLCom)
        self.additemFromNode(self.addItem_ChildrenIconName,self.IconCurrentChildrenFilelistL)
        self.addItem_ChildrenIconName.setEditText("aa ")
        self.addItem_ChildrenIconName.activated.connect(self.currentChildrenTextChange1)


        ################################################## close windows and save
        self.saveAllSetHot7 =QtWidgets.QPushButton(self)
        self.saveAllSetHot7.setGeometry(QtCore.QRect(370,500,80,25))
        self.saveAllSetHot7.setText("Save All")
        self.saveAllSetHot7.clicked.connect(self.saveAllSet)

        self.closeSetHot7 =QtWidgets.QPushButton(self)
        self.closeSetHot7.setGeometry(QtCore.QRect(460,500,80,25))
        self.closeSetHot7.setText("Close")
        self.closeSetHot7.clicked.connect(self.closeWindow)


        ###############slider_inside
        slider_insideIndexstartX = 40
        self.slider_insideIndex = QtWidgets.QSlider(QtCore.Qt.Horizontal, self)
        self.slider_insideIndex.setMinimum(1)
        self.slider_insideIndex.setMaximum(15)
        self.slider_insideIndex.setGeometry(slider_insideIndexstartX+120, 240, 160, 20)
        self.slider_insideEdit =QtWidgets.QLineEdit(self)
        self.slider_insideEdit.setGeometry(slider_insideIndexstartX+80,240,30,20)
        #start
        self.slider_insideIndex.setValue(self.fatherindex1)

        self.slider_insideLab =QtWidgets.QLabel(self)
        self.slider_insideLab.setGeometry(slider_insideIndexstartX,240,70,20)
        self.slider_insideLab.setText("Inside Num")
        self.slider_insideIndex.valueChanged.connect(self.slider_insideIndexCon)
        self.slider_insideEdit.textChanged.connect(self.slider_insideIndexTextCon)
        self.slider_insideEdit.setText(str(self.slider_insideIndex.value()))

        ###############slider_outSide
        slider_outSideIndexstartX = 40
        self.slider_outSideIndex = QtWidgets.QSlider(QtCore.Qt.Horizontal, self)
        self.slider_outSideIndex.setMinimum(1)
        self.slider_outSideIndex.setMaximum(15)
        self.slider_outSideIndex.setGeometry(slider_outSideIndexstartX+120, 280, 160, 20)
        self.slider_outSideIndex.setValue(self.childrenindex)
        self.slider_outSideEdit =QtWidgets.QLineEdit(self)
        self.slider_outSideEdit.setGeometry(slider_outSideIndexstartX+80,280,30,20)
        #start
        self.slider_outSideIndex.setValue(self.fatherindex1)
        self.slider_outSideLab =QtWidgets.QLabel(self)
        self.slider_outSideLab.setGeometry(slider_outSideIndexstartX,280,70,20)
        self.slider_outSideLab.setText("OutSide Num")
        self.slider_outSideIndex.valueChanged.connect(self.slider_outSideIndexCon)
        self.slider_outSideEdit.textChanged.connect(self.slider_outSideIndexTextCon)
        self.slider_outSideEdit.setText(str(self.slider_outSideIndex.value()))



        self.lineeditorHoudini = QtWidgets.QLabel(self)
        self.lineeditorHoudini.setGeometry(QtCore.QRect(60,600,150, 60))
        self.lineeditorHoudini.setObjectName("Houdini Hot Box 17")
        self.lineeditorHoudini.setText("Houdini Hot Box 17")
    def slider_insideIndexCon(self):
        self.slider_insideEdit.setText(str(self.slider_insideIndex.value()))

    def slider_insideIndexTextCon(self):
        self.slider_insideIndex.setValue(int( self.slider_insideEdit.text()) )

    def slider_outSideIndexTextCon(self):
        self.slider_outSideIndex.setValue(int( self.slider_outSideEdit.text()) )
    def slider_outSideIndexCon(self):
        self.slider_outSideEdit.setText(str(self.slider_outSideIndex.value()))


    def saveAllSet(self):
        self.reloadFatherInfo()

        #self.inSelectIndexArr   =[]
        #self.outSelectIndexArr  =[]
        #data file Path
        fileDataPath =WritePrefPath +nodeClass+r"/button/"+"button_"+str(self.inSelectIndexArr[-1]) +".data"
        fileFatherButtonNumPath = WritePrefPath +nodeClass+r"/button/"+"fatherButtonNum.dat"
        f1 = open(fileDataPath,"r")
        tempArr = f1.readlines()
        if  len(tempArr)< 30:
            for i in range(20):
                tempArr.append("\n")
        f1.close()
        PythonName =self.addItem_childrenNewName.currentText()
        IconName =self.addItem_childrenIconClass.currentText() + "/"+ self.addItem_ChildrenIconName.currentText()
        fatherName =self.addItem_Father.currentText()
        fatherIconName =self.addItem_FatherIcon.currentText() +"/"+self.addItem_FatherIconName.currentText()
        fatherCurrentIndex = str(self.slider_insideIndex.value())
        childCurrentIndex =str(self.slider_outSideIndex.value())

        f2= open(fileDataPath,"w")
        f2Index =-1
        for i in tempArr:
            f2Index+=1
            changeLine =i
            if i.split("=")[0] ==  "lab_"+str(self.outSelectIndexArr[-1]):
                changeLine = "lab_"+str(self.outSelectIndexArr[-1])+"="+PythonName+"="+IconName+"\n"
            if i.split("=")[0] == "fatherLab":
                changeLine ="fatherLab="+fatherName+"="+fatherIconName+"\n"
            if i.split("=")[0] == "childLabNumber":
                changeLine = "childLabNumber="+childCurrentIndex+"\n"
            if i == "\n":
                changeLine = "lab_"+str(f2Index-2)+"="+"smile"+"="+"COMMON/delete"+"\n"
            f2.write(changeLine)
        f2.close()

        #####write fatherButtonNum file
        f3 =open(fileFatherButtonNumPath,"w")
        f3.write("fatherButtonNum="+fatherCurrentIndex+"\n")

        f3.close()

        ############### updata init set
        s_button = s_GetButton.getButton(nodeClass)
        fatherNumer = s_button.getFatherButtonNum()

        self.update()


    def closeWindow(self):
        self.close()

    def additemFromNode(self,node,lists):
        node.clear()
        for text in lists:
            node.addItem(text)
    #Calculate the distance of each fan
    def getShapePos4 (self,shapeCenter,radio ):
        arrpos =[]
        arrpos.append(shapeCenter[0]-radio/2)
        arrpos.append(shapeCenter[1] - radio/2)
        arrpos.append(radio)
        arrpos.append(radio)
        return arrpos

    ##When changing the automatic completion of classicon changes group
    def currentTextChange(self):
        self.currentIconClassName1 =self.addItem_FatherIcon.currentText()
        self.IconCurrentFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentIconClassName1)
        self.IconCurrentFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentFilelistL)
        self.addItem_FatherIconName.setCompleter(self.IconCurrentFilelistLCom)
        self.additemFromNode(self.addItem_FatherIconName,self.IconCurrentFilelistL)
        self.addItem_FatherIconName.setEditText(self.tempCurrentIconName)
    def currentTextChange1(self):
        self.fatherIconViewPath = houdiniHotPathIconPath +self.addItem_FatherIcon.currentText()+"/" +self.addItem_FatherIconName.currentText()
        self.update()
     ##When changing the automatic completion of classicon changes group
    def  currentChildrenTextChange(self):
        self.currentChildrenIconClassName1 =self.addItem_childrenIconClass.currentText()

        self.IconCurrentChildrenFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentChildrenIconClassName1)
        self.IconCurrentChildrenFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentChildrenFilelistL)
        self.addItem_ChildrenIconName.setCompleter(self.IconCurrentChildrenFilelistLCom)
        self.additemFromNode(self.addItem_ChildrenIconName,self.IconCurrentChildrenFilelistL)
        self.addItem_ChildrenIconName.setEditText( self.tempCurrentChildrenIconName )

    def currentChildrenTextChange1(self):
         self.ChildrenIconViewPath = houdiniHotPathIconPath +self.addItem_childrenIconClass.currentText()+"/" +self.addItem_ChildrenIconName.currentText()
         self.update()
    def updatawindow(self):
        templineeditor_label3Text =""
        currentfatherIconName =""


        try:
            templineeditor_label3Text =self.readCurrentNameArr[-1][1]
            iconIndex = self.readCurrentNameArr[-1][0]
            currentfatherIconName =  self.fatherIconNameArr[iconIndex]
        except:
            pass
        #select inside
        self.lineeditor_label3.setText(templineeditor_label3Text)
        self.addItem_Father.setEditText(templineeditor_label3Text)
        self.addItem_FatherIcon.setEditText(currentfatherIconName.split("/")[0])
        self.currentIconClassName = currentfatherIconName.split("/")[0]

        #select outside
        self.lineeditor_label3_children.setText(self.runPythonName)
        self.addItem_childrenNewName.setEditText(self.runPythonName)

        try:

            self.IconCurrentFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentIconClassName)
            self.IconCurrentFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentFilelistL)
            self.addItem_FatherIconName.setCompleter(self.IconCurrentFilelistLCom)
            self.additemFromNode(self.addItem_FatherIconName,self.IconCurrentFilelistL)
            self.addItem_FatherIconName.setEditText(currentfatherIconName.split("/")[1])
            self.tempCurrentIconName =currentfatherIconName.split("/")[1]
        except:
            self.addItem_FatherIconName.setEditText("None")
        #set selectIconClass and Png Name
        self.addItem_childrenIconPath = "OBJ/switcher"
        try:
            self.addItem_childrenIconPath =self.childrenCurrentImageArr[self.outSelectIndexArr[-1]]
        except:
            pass
        #set Out Select Class
        self.addItem_childrenIconClass.setEditText(self.addItem_childrenIconPath.split("/")[0])
        self.currentIconChildrenClassName =self.addItem_childrenIconPath.split("/")[0]

        ##set out select iCON Name
        try:

            self.IconCurrentChildrenFilelistL =Hot7getIconF(houdiniHotPathIconPath + self.currentIconChildrenClassName)
            self.IconCurrentChildrenFilelistLCom =  QtWidgets.QCompleter(self.IconCurrentChildrenFilelistL)
            self.addItem_ChildrenIconName.setCompleter(self.IconCurrentChildrenFilelistLCom)
            self.additemFromNode(self.addItem_ChildrenIconName,self.IconCurrentChildrenFilelistL)
            self.addItem_ChildrenIconName.setEditText(self.addItem_childrenIconPath.split("/")[1])
            self.tempCurrentChildrenIconName =self.addItem_childrenIconPath.split("/")[1]
        except:
            self.addItem_ChildrenIconName.setEditText("None")
        ##setcurrentIcon
        self.fatherIconViewPath = houdiniHotPathIconPath +self.addItem_FatherIcon.currentText()+"/" +self.addItem_FatherIconName.currentText()
        self.ChildrenIconViewPath =houdiniHotPathIconPath +self.addItem_childrenIconClass.currentText()+"/" +self.addItem_ChildrenIconName.currentText()

        self.slider_outSideIndex.setValue(self.childrenindex)
        self.update()
    def drawIconFather(self,enent,qp):
        qp = QtGui.QPainter(self)

        qp.translate(510,120)
        qp.scale(0.5,0.5)
        image = QtGui.QImage(self.fatherIconViewPath)

        qp.drawImage(0,0,image)

    def drawIconChildren(self,enent,qp):
        try:
            qp = QtGui.QPainter(self)

            qp.translate(510,160)
            qp.scale(0.5,0.5)
            image = QtGui.QImage(self.ChildrenIconViewPath)
            qp.drawImage(0,0,image)
        except:
            pass
    def getDissMousetoShapeCenter(self,cellCenter,mousePose):
        newVector = [cellCenter[0]-mousePose[0],cellCenter[1]-mousePose[1]]
        lendiss = QtGui.QVector2D.length( QtGui.QVector2D(newVector[0],newVector[1]))
        return  lendiss
    def paintEvent(self, event):
        qp = QtGui.QPainter()

        qp.begin(self)
        self.drawLines1(event, qp)
        self.ellipsePathIn(event,qp)


        self.ellipsePathOut(event,qp)

        self.clickellipsePathIn(event,qp)

        self.clickellipsePathOut(event, qp)
        self.drawLines(event, qp)
        self.drawLines1(event, qp)
        self.ellipsePathmid(event,qp)


        self.ellipsePathIn1(event, qp)
        self.drawTextHoudini(event, qp)
        self.update()
        self.drawIconInside(event,qp)
        self.drawIconOutside(event,qp)
        self.drawTextInside(event,qp)
        self.drawTextOutside(event, qp)
        self.drawIconFather(event,qp)
        self.drawIconChildren(event,qp)


        qp.end()
    def drawTextHoudini(self,event,qp):
        pen = QtGui.QPen(QtGui.QColor(210, 120, 240, 255))
        qp.setPen(QtGui.QColor(self.insedeTextColor[0], self.insedeTextColor[1], self.insedeTextColor[2]))
        text ="Houdini HotBox 17.0"
        data ="2017/5/2 by Smile"
        textSize=30
        qp.setFont(QtGui.QFont("Decorative", textSize))
        qp.drawText(80,400,text)
        textSize = 8
        qp.setFont(QtGui.QFont("Decorative", textSize))
        qp.drawText(350, 420, data)
    def drawTextInside(self, event, qp):

        pen = QtGui.QPen(QtGui.QColor(self.lineColor[0], self.lineColor[1], self.lineColor[2], 255), 30)

        qp.setPen(pen)

        insider = self.insideShapeRs[0]/2+ ( self.insideShapeRs[1]/2-self.insideShapeRs[0]/2)/2
        index= -1
        for i in range(self.fatherindex1):
            index +=1
            qp.setPen(QtGui.QColor( self.insedeTextColor[0],  self.insedeTextColor[1],  self.insedeTextColor[2]))
            text = self.fatherNameArr[i]
            textLen = len(text)

            textSize = self.inSideTextSize
            qp.translate(self.cellCenterXY[0],self.cellCenterXY[1])
            injiange = 360/self.fatherindex1
            inx = insider*math.cos(math.radians(i*injiange+ injiange/2))
            iny =insider*math.sin(math.radians(i*injiange+ injiange/2))

            qp.setFont(QtGui.QFont("Decorative", textSize))

            qp.translate(inx,-iny)

            qp.drawText(-1* ((textLen*textSize/2 +((textLen+1)/4)*textSize ))/2,textSize/2+self.insideIconOffSetY ,text)
            try:
                if self.inSelectIndexArr[-1] == i :

                    qp.setPen(QtGui.QColor(self.selectTextColor[0], self.selectTextColor[1], self.selectTextColor[2]))
                    qp.drawText(-1 * ((textLen * textSize / 2 + ((textLen + 1) / 4) * textSize)) / 2, textSize / 2+self.insideIconOffSetY, text)
                    nameIndex =[index,text]

                    self.readCurrentNameArr.append(nameIndex)

            except:
                pass
            #qp.drawText(0,0, text)
            qp.resetTransform()
    def drawIconInside(self, event, qp):

        insider = self.insideShapeRs[0]/2+ ( self.insideShapeRs[1]/2-self.insideShapeRs[0]/2)/2
        initImageSize = [ self.inInitImageSize[0], self.inInitImageSize[1]]
        for i in range(self.fatherindex1):
            text = self.fatherNameArr[i]
            textLen = len(text)
            textSize = self.inSideTextSize

            image = QtGui.QImage(houdiniHotPathIconPath+"OBJ/switcher")
            try:
                if QtGui.QImage(houdiniHotPathIconPath+self.fatherIconNameArr[i]).size().width():
                    image = QtGui.QImage(houdiniHotPathIconPath+self.fatherIconNameArr[i])
            except:
                pass
            size =image.size()

            scaleImagex =initImageSize[0]*1.0/ size.width()
            scaleImagey = initImageSize[1]*1.0/size.height()


            qp.translate(self.cellCenterXY[0],self.cellCenterXY[1])
            injiange = 360/self.fatherindex1
            inx = insider*math.cos(math.radians(i*injiange+ injiange/2))
            iny =insider*math.sin(math.radians(i*injiange+ injiange/2))

            qp.translate(inx,-iny)
            qp.scale(scaleImagex,scaleImagey)
            #qp.drawImage(-1* ((textLen*textSize/2 +((textLen+1)/4)*textSize ))/2, -50-textSize,image)
            qp.setRenderHint(QtGui.QPainter().Antialiasing,True)
            qp.drawImage(-0.5*initImageSize[0],-1.0*initImageSize[1],image)

            qp.resetTransform()

    def drawTextOutside(self, event, qp):

        pen = QtGui.QPen(QtGui.QColor(self.lineColor[0], self.lineColor[1], self.lineColor[2], 255), 30)

        qp.setPen(pen)

        insider = self.outsideShapeRs[0] / 2 + (self.outsideShapeRs[1] / 2 - self.outsideShapeRs[0] / 2) / 2

        startAngle = (self.insideTextAngele - (self.childrenindex * self.childrenAngleRange) * 1.0 / 2)%360
        self.childNmaeArr =[]
        for i in  range(self.childrenindex):
            # read file bt current inSelectIndexArr
            #['name', 'iconName', 6, [['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName']]]
            #if inSelectIndexArr[-1] :
                # read file name+"inSelectIndexArr[-1]"
                #append getnum
            try:
                self.childNmaeArr.append(s_button.getButton_indexInfo(self.inSelectIndexArr[-1])[3][i])
            except:
                pass

        for i in range(self.childrenindex):
            qp.setPen(QtGui.QColor(self.outSideTextColor[0], self.outSideTextColor[1], self.outSideTextColor[2]))
            text= ""
            try:
                text = self.childNmaeArr[i][0]
            except:
                pass
            textLen = len(text)

            textSize = self.outSideTextSize
            qp.translate(self.cellCenterXY[0],self.cellCenterXY[1])
            injiange = self.childrenAngleRange
            angle =((startAngle +injiange*i)+injiange/2)%360
            inx = insider * math.cos(math.radians(angle))
            iny = insider * math.sin(math.radians(angle))

            qp.setFont(QtGui.QFont("Decorative", textSize))

            qp.translate(inx, -iny)

            qp.drawText(-1 * ((textLen * textSize / 2 + ((textLen + 1) / 4) * textSize)) / 2, textSize / 2+self.OutSideIconOffSetY, text)
            try:
                if self.outSelectIndexArr[-1] == i  and  self.lenMouse >self.insideShapeRs[1]/2 :
                    qp.setPen(QtGui.QColor(self.selectTextColor[0], self.selectTextColor[1], self.selectTextColor[2]))
                    qp.drawText(-1 * ((textLen * textSize / 2 + ((textLen + 1) / 4) * textSize)) / 2, textSize / 2+self.OutSideIconOffSetY,
                                text)
                    self.runPythonName=text

            except:
                pass
            # qp.drawText(0,0, text)
            qp.resetTransform()
    def drawIconOutside(self, event, qp):
        initImageSize = [self.OutInitImageSize[0],self.OutInitImageSize[1]]


        insider = self.outsideShapeRs[0] / 2 + (self.outsideShapeRs[1] / 2 - self.outsideShapeRs[0] / 2) / 2

        startAngle = (self.insideTextAngele - (self.childrenindex * self.childrenAngleRange) * 1.0 / 2)%360
        self.childNmaeArr =[]
        self.childIconNmaeArr =[]
        for i in  range(self.childrenindex):
            # read file bt current inSelectIndexArr
            #['name', 'iconName', 6, [['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName'], ['name', 'iconName']]]
            #if inSelectIndexArr[-1] :
                # read file name+"inSelectIndexArr[-1]"
                #append getnum
            try:
                self.childNmaeArr.append(s_button.getButton_indexInfo(self.inSelectIndexArr[-1])[3][i])
            except:
                pass
        self.childrenCurrentImageArr =[]
        for i in range(self.childrenindex):
            qp.setPen(QtGui.QColor(20, 34, 3))
            text= ""

            imagePath ="OBJ/switcher"
            try:
                text = self.childNmaeArr[i][0]
                if QtGui.QImage(houdiniHotPathIconPath+self.childNmaeArr[i][1]):
                    imagePath =  self.childNmaeArr[i][1]
            except:
                #check install icon
                return 0
            textLen = len(text)
            textSize = self.outSideTextSize
            image =QtGui.QImage(houdiniHotPathIconPath+imagePath)

            self.childrenCurrentImageArr.append(imagePath)
            size =image.size()
            scaleImagex =initImageSize[0]*1.0/ size.width()
            scaleImagey = initImageSize[1]*1.0/size.height()

            qp.translate(self.cellCenterXY[0],self.cellCenterXY[1])
            injiange = self.childrenAngleRange
            angle =((startAngle +injiange*i)+injiange/2)%360
            inx = insider * math.cos(math.radians(angle))
            iny = insider * math.sin(math.radians(angle))
            qp.translate(inx, -iny)
            qp.scale(scaleImagex,scaleImagey)
            qp.drawImage(-0.5* size.width(),-1.0*size.height(),image)

            qp.resetTransform()

    def ellipsePathIn (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[1])

        #QBrush(QPixmap("images/brick.png")
        #QtGui.QColor( self.insideColor[0], self.insideColor[1],self.insideColor[2])
        qp.setBrush(QtGui.QBrush(QtGui.QPixmap(houdiniHotPathIconPath+"ground")))
        index = self.fatherindex1
        self.fatherindex= self.fatherindex1
        fenge = 1
        perA= 360/index

        for i in range(index):

            startAngle = perA*i+fenge
            endAngle   = perA-fenge
            #in inside
            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
            path.arcTo(inellPose[0]-20,inellPose[1],inellPose[2]+40,inellPose[3],startAngle,endAngle)
            #out inside
            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
            path.arcTo(outellPose[0],outellPose[1],outellPose[2],outellPose[3],startAngle,endAngle)

            path.setFillRule(QtCore.Qt.OddEvenFill)

        qp.drawPath(path)
    def ellipsePathIn1 (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[1])

        #QBrush(QPixmap("images/brick.png")
        #QtGui.QColor( self.insideColor[0], self.insideColor[1],self.insideColor[2])
        qp.setBrush(QtGui.QColor(self.insideColor[0], self.insideColor[1], self.insideColor[2],50))
        index = 2
        self.fatherindex= self.fatherindex1
        fenge = 0
        perA= 360/index

        for i in range(index):

            startAngle = perA*i+fenge
            endAngle   = perA-fenge
            #in inside
            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
            path.arcTo(inellPose[0]-20,inellPose[1],inellPose[2]+40,inellPose[3],startAngle,endAngle)


            path.setFillRule(QtCore.Qt.OddEvenFill)

        qp.drawPath(path)

    def clickellipsePathIn (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.insideShapeRs[1])


        qp.setBrush(QtGui.QColor(self.selectColor[0], self.selectColor[1], self.selectColor[2],200))
        index = self.fatherindex
        fenge = 1
        perA= 360/index
        posmouthx=0
        posmouthy = 0
        try:
            posmouthx =self.line[-1].x()-self.cellCenterXY[0]
            posmouthy = self.cellCenterXY[1] -self.line[-1].y()

        except:

            pass
        pos =[posmouthx,posmouthy]
        bpos = [1,0]
        mouthAngle =getangle(pos,bpos )

        lenMouse = self.getDissMousetoShapeCenter(pos,[0,0])
        self.lenMouse =lenMouse
        if(lenMouse < self.insideShapeRs[1]/2):
            self.mouseAngleArr.append(mouthAngle)


        for i in range(self.fatherindex):
            if self.mouseAngleArr[-1]>i*perA and self.mouseAngleArr[-1]<(i+1)*perA :
                startAngle = perA*i+fenge
                endAngle   = perA-fenge
                #in inside
                #path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                #path.arcTo(inellPose[0]-20,inellPose[1],inellPose[2]+40,inellPose[3],startAngle,endAngle)
                #out inside
                path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                path.arcTo(outellPose[0],outellPose[1],outellPose[2],outellPose[3],startAngle,endAngle)

                path.setFillRule(QtCore.Qt.OddEvenFill)
                self.inSelectIndexArr.append(i)

        qp.drawPath(path)
    #bianyuan start
    def ellipsePathmid (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.midsideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.midsideShapeRs[1])


        qp.setBrush(QtGui.QColor( self.insideColor[0], self.insideColor[1],self.insideColor[2]))
        index = 1
        fenge = 0
        perA= 360/index
        self.fatherindex =index
        for i in range(1):

            startAngle = perA*i+fenge
            endAngle   = perA-fenge
            #in inside
            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
            path.arcTo(inellPose[0],inellPose[1],inellPose[2],inellPose[3],startAngle,endAngle)
            #out inside
            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
            path.arcTo(outellPose[0],outellPose[1],outellPose[2],outellPose[3],startAngle,endAngle)

            path.setFillRule(QtCore.Qt.OddEvenFill)

        qp.drawPath(path)
    #bianyuan end
    def ellipsePathOut (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.outsideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.outsideShapeRs[1])
        qp.setBrush(QtGui.QBrush(QtGui.QPixmap(houdiniHotPathIconPath+"ground")))
        index =5
        try:
            index =self.childrenallIndexArr[self.inSelectIndexArr[-1]]
        except:
            pass
        self.childrenindex = index
        fenge = 0.5
        perA = self.childangleRangeset

        self.childrenAngleRange =perA
        fatherAngle =0
        if self.mouseAngleArr[-1]:
            fatherAngle =(math.ceil( self.mouseAngleArr[-1]/(360/ self.fatherindex))-0.5)*(360/ self.fatherindex)
        self.insideTextAngele =fatherAngle
        startAngle = fatherAngle -(index*perA)*1.0/2
        try:
            if self.inSelectIndexArr[-1]>-1:
                for a in range(index):
                    endAngle =perA
                    path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                    path.arcTo(inellPose[0], inellPose[1], inellPose[2], inellPose[3], startAngle+fenge, endAngle-fenge)
                    # out inside
                    path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                    path.arcTo(outellPose[0], outellPose[1], outellPose[2], outellPose[3], startAngle+fenge, endAngle-fenge)

                    path.setFillRule(QtCore.Qt.OddEvenFill)
                    startAngle+=perA



                qp.drawPath(path)
        except:
            pass

    def clickellipsePathOut (self,event,qp):
        path = QtGui.QPainterPath()
        inellPose = self.getShapePos4(self.cellCenterXY, self.outsideShapeRs[0])
        outellPose = self.getShapePos4(self.cellCenterXY, self.outsideShapeRs[1])

        qp.setBrush(QtGui.QColor(self.selectColor[0], self.selectColor[1], self.selectColor[2],200))
        index = self.childrenindex
        fenge = 2
        perA =  self.childrenAngleRange
        posmouthx = 0
        posmouthy = 0
        try:
            posmouthx = self.line[-1].x() - self.cellCenterXY[0]
            posmouthy = self.cellCenterXY[1] - self.line[-1].y()

        except:
            pass
        pos = [posmouthx, posmouthy]
        bpos = [1, 0]
        mouthAngle = getangle(pos, bpos)

        lenMouse = self.getDissMousetoShapeCenter(pos, [0, 0])

        if (lenMouse > self.insideShapeRs[1] / 2):
            try:
                self.chindrenMouseAngleArr.append(int(mouthAngle))
            except:
                pass
        fatherAngle = 0
        if self.mouseAngleArr[-1]:
            fatherAngle =(math.ceil( self.mouseAngleArr[-1]/(360/ self.fatherindex))-0.5)*(360/ self.fatherindex)
        startAngle =( fatherAngle - (index * perA) * 1.0 / 2) %360
        tempStartAngle =( fatherAngle - (index * perA) * 1.0 / 2) %360
        tempLastStartAngle = ((fatherAngle - (index * perA) * 1.0 / 2) % 360)*(index-1)%360
        if (lenMouse > self.insideShapeRs[1] / 2):
            for i in range(self.childrenindex):

                if self.chindrenMouseAngleArr[-1] >startAngle and self.chindrenMouseAngleArr[-1] < startAngle+ perA:

                    endAngle = perA
                    # in inside
                    path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                    path.arcTo(inellPose[0], inellPose[1], inellPose[2], inellPose[3], startAngle, endAngle)
                    # out inside
                    path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                    path.arcTo(outellPose[0], outellPose[1], outellPose[2], outellPose[3], startAngle, endAngle)

                    path.setFillRule(QtCore.Qt.OddEvenFill)
                    self.outSelectIndexArr.append(i)
                else:
                    try:
                        if i ==  self.outSelectIndexArr[-1]  :
                            endAngle = perA
                            # in inside
                            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                            path.arcTo(inellPose[0], inellPose[1], inellPose[2], inellPose[3], startAngle, endAngle)
                            # out inside
                            path.moveTo(self.cellCenterXY[0], self.cellCenterXY[1])
                            path.arcTo(outellPose[0], outellPose[1], outellPose[2], outellPose[3], startAngle, endAngle)

                            path.setFillRule(QtCore.Qt.OddEvenFill)
                    except:
                        pass
                #over select angle


                startAngle = (startAngle+perA)%360

            qp.drawPath(path)

    def drawLines(self,event, qp):
        pen = QtGui.QPen(QtGui.QColor(self.lineColor[0], self.lineColor[1], self.lineColor[2], 255),self.lineWidth)
        qp.setPen(pen)
        index = len(self.line)
        for i in range( index):
            qp.drawLine(self.line[0],self.line[-1])
            #qp.drawLine(self.line[1],self.line[-1])
    def drawLines1(self,event, qp):
        pen = QtGui.QPen(QtGui.QColor(self.lineColor[0], self.lineColor[1], self.lineColor[2], 255),0.0001)
        qp.setPen(pen)
    def drawLines2(self,event, qp):
        pen = QtGui.QPen(QtGui.QColor(self.lineColor[0], self.lineColor[1], self.lineColor[2], 255),0.0001)
        qp.setPen(pen)
    def mousePressEvent(self, en):
        self.isPressed = 1
        self.startPos =QtCore.QPoint(250,250)
        self.endPose = en.pos()

    def mouseReleaseEvent(self, en):
        self.isPressed = 0
        #self.runHoudiniPython()
        #self.close()



    def mouseMoveEvent(self, en):
        #if self.isPressed:
        self.startPos =QtCore.QPoint(self.cellCenterXY[0],self.cellCenterXY[1])
        self.endPose = en.pos()

        self.line.append(self.startPos)
        self.line.append(self.endPose)
        self.line[1] =self.endPose

        self.update()

        self.line[-1] =self.endPose
        self.updatawindow()

    def runHoudiniPython(self):
        try:

            if  self.runPythonName != "":
            #try:
                lastNodeName = "import " + self.runPythonName
                runNodeName = "a ="+self.runPythonName+"."+self.runPythonName+"()"



                exec(lastNodeName)
                exec(runNodeName)
                a.run()

        except Exception as e:
            print e

      

 
    