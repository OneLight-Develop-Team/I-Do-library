class smilerbd:
    def __init__(self):
        self.a =188
    def run(self):
        print "this is rbd :::",self.a